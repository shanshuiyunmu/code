#include "CPoint.h"
#include<math.h>

//���캯��,��ʼ�������뷽���G,H,F
CPoint::CPoint(int x, int y , int dir):m_cur(x,y,dir)
{
	m_G = 0;
	m_H = 0;
	m_F = 0;
}


CPoint::~CPoint()
{
}

//����4����
void CPoint::CreatNode(CPoint arr[], CPoint endPos)
{
	int y[4] = { 0,0,-1,+1 };
	int x[4] = { -1,+1,0,0 };
	for (int i = 0; i < 4; ++i)
	{
		arr[i] = *this;
		arr[i].m_pre = m_cur;
		arr[i].m_cur.m_dir = i;
		arr[i].m_cur.m_x += x[i];
		arr[i].m_cur.m_y += y[i];
		arr[i].m_G += 1;
		arr[i].m_H = abs(arr[i].m_cur.m_x - endPos.m_cur.m_x) + abs(arr[i].m_cur.m_y - endPos.m_cur.m_y);
		arr[i].m_F = arr[i].m_H + arr[i].m_G;
	}
	
}

int CPoint::GetDir()
{
	return m_cur.m_dir;
}

int CPoint::GetX()
{
	return m_cur.m_x;
}

int CPoint::GetY()
{
	return m_cur.m_y;
}

void CPoint::SetDir(int num)
{
	 m_cur.m_dir=num;
}

//����<�����
bool operator<(const CPoint & l, const CPoint & r)
{
	return l.m_F<r.m_F;
}
