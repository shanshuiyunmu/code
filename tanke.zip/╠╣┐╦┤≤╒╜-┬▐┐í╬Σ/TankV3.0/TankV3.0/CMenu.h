#pragma once
#include"CBase.h"
#include"CGame.h"
class CMenu :public CBase
{
private:
	CGame m_game;//����һ����Ϸ����
public:                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 
	CMenu();
	~CMenu();

	//����
	int MenuGame();

	//����˵�
	int MasterTree();

};

