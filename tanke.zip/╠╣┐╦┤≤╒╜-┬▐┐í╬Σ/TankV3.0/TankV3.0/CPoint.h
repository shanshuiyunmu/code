#pragma once
struct BasePoint
{
	int m_x=0;//����,����
	int m_y=0;
	int m_dir=0;
	BasePoint(int x = 0, int y = 0,int dir = 0)
	{
		m_x = x; m_y = y; m_dir = dir;
	}
	bool operator==(const BasePoint& o)
	{
		return m_x == o.m_x && m_y == o.m_y;
	}

};
class CPoint
{
public:
	CPoint(int x = 0, int y = 0, int dir = 0);
	~CPoint();
	friend bool operator<(const CPoint& l, const CPoint& r);
	void CreatNode(CPoint arr[], CPoint endPos);
	int GetDir();
	int GetX();
	int GetY();
	void SetDir(int num);
	friend class CAstar;
private:
	int m_G;//�ƶ����
	int m_H;//����
	int m_F;//����֮��,G+H
	BasePoint m_pre;//��һ����
	BasePoint m_cur;//����
};

