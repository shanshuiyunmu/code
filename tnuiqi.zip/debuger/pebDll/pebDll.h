#pragma once


extern "C" __declspec(dllexport) bool queryInfo(char* name, char* ver);

extern "C" __declspec(dllexport) void runPlugin(HANDLE prohandle);

extern "C" __declspec(dllexport) void clearPlugin();
