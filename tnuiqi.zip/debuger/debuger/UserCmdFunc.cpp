#include "UserCmdFunc.h"
#include <iostream>
#include <DbgHelp.h>
#pragma comment(lib,  "dbghelp.lib")

UserCmdFunc::UserCmdFunc()
{
}


UserCmdFunc::~UserCmdFunc()
{
}
//��ʾ�Ĵ���
void UserCmdFunc::ShowRegs(HANDLE threadHandle)
{
	//��ȡ���еļĴ���
	CONTEXT regInfo = { CONTEXT_ALL };
	GetThreadContext(threadHandle, &regInfo);
	//����Ĵ�����ֵ
	printf("eax=%08x ebx=%08x ecx=%08x edx=%08x \nesi=%08x edi=%08x eip=%08x esp=%08x ebp=%08x\ncs=%04x ss=%04x ds=%04x es=%04x fs=%04x gs=%04x efl=%08x\n", regInfo.Eax, regInfo.Ebp, regInfo.Ecx, regInfo.Edx, regInfo.Esi, regInfo.Edi,
		regInfo.Eip, regInfo.Esp, regInfo.Ebp, regInfo.SegCs, regInfo.SegSs, regInfo.SegDs,
		regInfo.SegEs, regInfo.SegFs, regInfo.SegGs, regInfo.EFlags);
}
//��ʾ��ջ��Ϣ
void UserCmdFunc::Showstack(HANDLE hProcess,HANDLE threadHandle)
{
	//��ÿ��ƼĴ�����ֵ
	CONTEXT regInfo = { CONTEXT_CONTROL };
	//�õ��̻߳���
	GetThreadContext(threadHandle, &regInfo);
	//��ö�ջ�ռ��С
	int num = &regInfo.Esp - &regInfo.Ebp;
	for (int i = 0; i < num; i++)
	{
		//���esp�ĵ�ַ
		DWORD addr = regInfo.Esp+i*4;
		DWORD var;
		DWORD dwRead;
		//�ڱ����Խ�����,��ȡesp������
		ReadProcessMemory(hProcess, (LPVOID)addr, &var, 4, &dwRead);
		//���esp��ַ��esp������
		printf("%08x: %08x\n", addr, var);
	}
}
//�鿴�ڴ�����
void UserCmdFunc::ShowMem(HANDLE hProcess, DWORD addr)
{
	BYTE var[100] = {};
	DWORD dwRead;
	//��ȡ�����Խ��̵ĵ�ַ���ڵ�����,��100���ֽ�
	ReadProcessMemory(hProcess, (LPVOID)addr, var,100, &dwRead);
	//����ڴ�����
	for (int i = 0; i < 100; i++)
	{
		//��16��������ʽ���
		printf("%02x ", var[i]);
		//ÿ25�ֽڻ�һ��
		if ((i+1) % 25 == 0)
		{
			printf("\n");
		}
	}
	//���һ��
	printf("\n");
	
}
//�޸��ڴ���Ϣ
void UserCmdFunc::ChangeMem(HANDLE hProcess, DWORD addr,LPVOID buffer)
{
	DWORD dwWrite;
	DWORD flOldProtect;
	//�޸��ڴ��������
	VirtualProtectEx(hProcess, (LPVOID)addr, 1, PAGE_READWRITE, &flOldProtect);
	//������д�뱻���Խ��̵�ָ����ַ
	WriteProcessMemory(hProcess, (LPVOID)addr, buffer, strlen((LPCSTR)buffer), &dwWrite);
	//��ԭ�ڴ��������
	VirtualProtectEx(hProcess, (LPVOID)addr, 1, flOldProtect, &flOldProtect);
}
//�޸ļĴ���
void UserCmdFunc::ChangeReg(HANDLE threadHandle,LPCSTR reg,DWORD regValue)
{
	//������мĴ�����ֵ
	CONTEXT regInfo = { CONTEXT_ALL };
	GetThreadContext(threadHandle, &regInfo);
	//�޸Ķ�Ӧ�Ĵ�����ֵ
	if (strcmp(reg, "eax")==0)
	{
		regInfo.Eax = regValue;
	}
	else if (strcmp(reg, "ebx") == 0)
	{
		regInfo.Ebx = regValue;
	}
	else if (strcmp(reg, "ecx") == 0)
	{
		regInfo.Ecx = regValue;
	}
	else if (strcmp(reg, "edx") == 0)
	{
		regInfo.Edx = regValue;
	}
	else if (strcmp(reg, "esp") == 0)
	{
		regInfo.Esp = regValue;
	}
	else if (strcmp(reg, "ebp") == 0)
	{
		regInfo.Ebp = regValue;
	}
	else if (strcmp(reg, "esi") == 0)
	{
		regInfo.Esi = regValue;
	}
	else if (strcmp(reg, "edi") == 0)
	{
		regInfo.Edi = regValue;
	}
	else if (strcmp(reg, "eip") == 0)
	{
		regInfo.Eip = regValue;
	}
	else if (strcmp(reg, "es") == 0)
	{
		regInfo.SegEs = regValue;
	}
	else if (strcmp(reg, "cs") == 0)
	{
		regInfo.SegCs = regValue;
	}
	else if (strcmp(reg, "ss") == 0)
	{
		regInfo.SegSs = regValue;
	}
	else if (strcmp(reg, "ds") == 0)
	{
		regInfo.SegDs = regValue;
	}
	else if (strcmp(reg, "fs") == 0)
	{
		regInfo.SegFs = regValue;
	}
	else if (strcmp(reg, "efl") == 0)
	{
		regInfo.EFlags = regValue;
	}
	//���޸ĺ�ļĴ�������,��ŵ��̻߳�����
	SetThreadContext(threadHandle, &regInfo);
}
//�޸Ļ�����
void UserCmdFunc::ChangeAsm(HANDLE hProcess, DWORD addr, LPVOID value,DWORD size)
{
	DWORD floldprotect;
	//�޸��ڴ��������
	VirtualProtectEx(hProcess, (LPVOID)addr, 1, PAGE_READWRITE, &floldprotect);
	DWORD dwReal;
	//������д�뱻���Խ���ָ���ĵ�ַ
	WriteProcessMemory(hProcess, (LPVOID)addr, value, size, &dwReal);
	//��ԭ�ڴ��������
	VirtualProtectEx(hProcess, (LPVOID)addr, 1, floldprotect, &floldprotect);
}
//��ʾ������
void UserCmdFunc::ShowDllEx(HANDLE hfile, DWORD addr)
{
	char* buff = new char[0x1000];
	DWORD dwreal;
	ReadProcessMemory(hfile, (LPVOID)addr, buff, 0x1000, &dwreal);
	//���dosͷ
	PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)buff;
	//���ntͷ
	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)(pDos->e_lfanew + (DWORD)pDos);
	//��õ�����
	DWORD addrEx = ((DWORD)pNtHeader->OptionalHeader.DataDirectory[0].VirtualAddress + addr);
	DWORD exSize = pNtHeader->OptionalHeader.DataDirectory[0].Size;
	char* buff4 = new char[exSize];
	ReadProcessMemory(hfile, (LPVOID)addrEx, buff4, exSize, &dwreal);
	PIMAGE_EXPORT_DIRECTORY pEx =(PIMAGE_EXPORT_DIRECTORY)buff4;

	//���IAT,INT,ORD�ĵ�ַ
	DWORD addrIAT =pEx->AddressOfFunctions + addr;
	DWORD addrINT = pEx->AddressOfNames + addr;
	DWORD addrORD = pEx->AddressOfNameOrdinals + addr;
	char* buff1 = new char[4 * pEx->NumberOfNames];
	ReadProcessMemory(hfile, (LPVOID)addrIAT, buff1, 4 * pEx->NumberOfNames, &dwreal);
	DWORD* pIAT = (DWORD*)buff1;
	char* buff2 = new char[4 * pEx->NumberOfFunctions];
	ReadProcessMemory(hfile, (LPVOID)addrINT, buff2, 4 * pEx->NumberOfFunctions, &dwreal);
	DWORD* pINT = (DWORD*)buff2;
	char* buff3 = new char[2 * pEx->NumberOfNames];
	ReadProcessMemory(hfile, (LPVOID)addrORD, buff3, 2 * pEx->NumberOfNames, &dwreal);
	WORD* pORD = (WORD*)buff3;
	char* name = new char[100];
	
	//����������,iat
	for (UINT i = 0; i < pEx->NumberOfFunctions; i++)
	{
		bool flag = false;
		//int,ord
		for (UINT j = 0; j < pEx->NumberOfNames; j++)
		{
			if (i == pORD[j])
			{
				//˵�������Ƶ���
				ReadProcessMemory(hfile, (LPVOID)(pINT[j] + addr), name, 100, &dwreal);
				printf("���:%04d  ", pORD[j]+pEx->Base);
				printf("��ַ:%08x  ", pIAT[i] + addr);
				printf("����:%s\n", name);
				
				flag = true;
			}
		}
		if (flag == false)
		{
			//˵������ŵ���
			printf("���:%04d  ", i + pEx->Base);
			printf("��ַ:%08x  ", pIAT[i] + addr);
			printf("����:null\n");
			
		}
	}
	delete[] buff;
	delete[] buff1;
	delete[] buff2;
	delete[] buff3;
	delete[] buff4;
	delete[] name;
}

//��ʾ�����
void UserCmdFunc::ShowDllIm(HANDLE hfile, DWORD addr)
{
	char* buff = new char[0x1000];
	DWORD dwreal;
	ReadProcessMemory(hfile, (LPVOID)addr, buff, 0x1000, &dwreal);
	//���dosͷ
	PIMAGE_DOS_HEADER pDos = (PIMAGE_DOS_HEADER)buff;
	//���ntͷ
	PIMAGE_NT_HEADERS pNtHeader = (PIMAGE_NT_HEADERS)(pDos->e_lfanew + (DWORD)pDos);
	//��õ�����
	DWORD addrIm = ((DWORD)pNtHeader->OptionalHeader.DataDirectory[1].VirtualAddress + addr);
	DWORD imSize = pNtHeader->OptionalHeader.DataDirectory[1].Size;
	if (addrIm == NULL)
	{
		MessageBox(NULL, "û�е����", "��ʾ", MB_OK);
		return;
	}
	char* buff4 = new char[imSize];
	char* buff1 = new char[0x1000];
	char* buff2 = new char[0x1000];
	char* buffname = new char[100];
	ReadProcessMemory(hfile, (LPVOID)addrIm, buff4, imSize, &dwreal);
	PIMAGE_IMPORT_DESCRIPTOR pIm = (PIMAGE_IMPORT_DESCRIPTOR)buff4;

	//���������
	while (pIm->Name)
	{
		//���dll����
		ReadProcessMemory(hfile, (LPVOID)(pIm->Name + addr), buffname, 100, &dwreal);
		printf("dll����:%s\n\n", buffname);

		//�ҵ�IAT,INT ��ַ
		DWORD addrIAT = pIm->FirstThunk + addr;
		DWORD addrINT = pIm->OriginalFirstThunk + addr;
		ReadProcessMemory(hfile, (LPVOID)addrIAT, buff1, 0x1000, &dwreal);
		PIMAGE_THUNK_DATA32 pIAT = (PIMAGE_THUNK_DATA32)buff1;
		ReadProcessMemory(hfile, (LPVOID)addrINT, buff2, 0x1000, &dwreal);
		PIMAGE_THUNK_DATA32 pINT = (PIMAGE_THUNK_DATA32)buff2;
		while (pINT->u1.Ordinal)
		{
			if (pINT->u1.Ordinal & 0x80000000)
			{
				//��ŵ���
				printf("���:%04d", pINT->u1.Ordinal);
				printf("��ַ:%08x", pIAT->u1.AddressOfData + addr);
				printf("����:NULL");
			}
			else
			{
				//���Ƶ���
				ReadProcessMemory(hfile, (LPVOID)(pINT->u1.AddressOfData + addr), buffname, 100, &dwreal);
				PIMAGE_IMPORT_BY_NAME name = (PIMAGE_IMPORT_BY_NAME)buffname;
				printf("���:%04d  ", name->Hint);
				printf("��ַ:%08x  ", pIAT->u1.AddressOfData + addr);
				printf("����:%s\n", name->Name);

			}
			pINT++;
			pIAT++;
		}
		pIm++;
	}
	delete[] buff;
	delete[] buff1;
	delete[] buff2;
	delete[] buff4;
	delete[] buffname;
}
//����DUMP�ļ�
void UserCmdFunc::CreateDump(HANDLE hProcess, DWORD hProcessID, DWORD threadID, _EXCEPTION_POINTERS * ExceptionInfo)
{
	//�����ļ���
	std::string dmpFileName = "dumpfile";
	std::string strDumpFile = "";
	SYSTEMTIME syt;
	GetLocalTime(&syt);
	char c[MAX_PATH];
	sprintf_s(c, MAX_PATH, "[%04d-%02d-%02d %02d��%02d��%02d]", syt.wYear, syt.wMonth, syt.wDay, syt.wHour, syt.wMinute, syt.wSecond);
	strDumpFile = std::string(c);
	if (!dmpFileName.empty())
	{
		strDumpFile += dmpFileName;
	}
	strDumpFile += std::string(".dmp");

	//����dump�ļ�
	HANDLE hFile = CreateFileA(strDumpFile.c_str(), GENERIC_WRITE, FILE_SHARE_WRITE, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);

	//
	if (hFile != INVALID_HANDLE_VALUE)
	{
		MINIDUMP_EXCEPTION_INFORMATION   ExInfo;
		ExInfo.ThreadId = threadID;
		ExInfo.ExceptionPointers = ExceptionInfo;
		ExInfo.ClientPointers = FALSE;
		//   write   the   dump
		BOOL   bOK = MiniDumpWriteDump(hProcess, hProcessID, hFile, MiniDumpNormal, &ExInfo, NULL, NULL);
		CloseHandle(hFile);	
	}
	else
	{
		
	}
}
